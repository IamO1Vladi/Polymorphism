﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    internal interface IEngine
    {
        public void Run();
    }
}
