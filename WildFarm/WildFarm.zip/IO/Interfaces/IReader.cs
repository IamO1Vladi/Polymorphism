﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.IO.Interfaces
{
    internal interface IReader
    {

        public string ReadLine();

    }
}
