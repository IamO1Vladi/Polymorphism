﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.IO.Interfaces
{
    internal interface IWritter
    {

        public void WriteLine(string text);
        public void Write(string text);

    }
}
