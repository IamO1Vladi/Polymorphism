﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Core
{
    internal interface IEngine
    {

        public void Run();
    }
}
