﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Food
{
    internal class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
