﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphism.IO.Interfaces
{
    internal interface IReader
    {

        public string ReadLine();

    }
}
