﻿using Polymorphism.IO.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphism.Core
{
    internal interface IEngine
    {
        public void Run();
    }
}
